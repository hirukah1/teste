#!/bin/bash

# This script is no longer needed and only provided for backwards compatibility.

SCRIPT=$(readlink -f "$0")
PATH=$(dirname "$SCRIPT")

exec "$PATH/Tibia"
